﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    class TaskMap : EntityTypeConfiguration<Task>
    {
        public TaskMap()
        {
            this.HasKey(u => u.Id);
            this.HasMany(t => t.Documents).WithOptional(d => d.Task);
            this.HasOptional(u => u.TaskAdmin).WithMany(p => p.TaskAdmins);
        }
    }
    
    public class Task : Entity
    {
        public string Name { get; set; }
        public string Text { get; set; }
        public User TaskAdmin { get; set; }
        public User TaskAssignee { get; set; }
        public TaskProgress TaskProgress { get; set; }
        public virtual IList<Document> Documents { get; set; }
        public Project Project { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public TaskPriority TaskPriority { get; set; }

    }
}
