﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    public class Document : Entity
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public User DocumentOwner { get; set; }
        public Task Task { get; set; }

    }
}
