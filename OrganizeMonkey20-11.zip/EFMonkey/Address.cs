﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    class AddressMap : EntityTypeConfiguration<Address>
    {
        public AddressMap()
        {
            this.HasKey(u => u.Id);         
        }
    }
    public class Address : Entity
    {
        public string Street { get; set; }
        public string City { get; set; }
        public int Postcode { get; set; }

        public virtual User User { get; set; }
    }
}
