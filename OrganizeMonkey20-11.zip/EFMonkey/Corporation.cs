﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    class CorporationMap : EntityTypeConfiguration<Corporation>
    {
        public CorporationMap()
        {
            this.HasKey(ct => ct.Id);
        }
    }

    public class Corporation : Entity
    {
        public string Name { get; set; }
        
        public virtual IList<User> CorporationUsers { get; set; }
        public virtual IList<Project> CorporationProjects { get; set; }
        
    }
}
