﻿using System;
using System.Data.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace  EFMonkey
{
    public class EFMonkeyInitializer : DropCreateDatabaseIfModelChanges<EFMonkeyContext>
    //public class EFMonkeyInitializer : DropCreateDatabaseAlways<EFMonkeyContext>
    {
        protected override void Seed(EFMonkeyContext context)
        {
            IList<TaskPriority> defaultTaskPriority = new List<TaskPriority>();

            defaultTaskPriority.Add(new TaskPriority() { Name = "Niedrig", PriorityValue = 1 });
            defaultTaskPriority.Add(new TaskPriority() { Name = "Normal", PriorityValue = 2 });
            defaultTaskPriority.Add(new TaskPriority() { Name = "Hoch", PriorityValue = 3 });

            foreach (TaskPriority tp in defaultTaskPriority)
                context.TaskPriority.Add(tp);

            IList<TaskProgress> defaultTaskProgress = new List<TaskProgress>();

            defaultTaskProgress.Add(new TaskProgress() { Name = "Offen" });
            defaultTaskProgress.Add(new TaskProgress() { Name = "In Bearbeitung" });
            defaultTaskProgress.Add(new TaskProgress() { Name = "Beendet" });
            defaultTaskProgress.Add(new TaskProgress() { Name = "Erledigt" });

            foreach (TaskProgress tpr in defaultTaskProgress)
                context.TaskProgress.Add(tpr);

            base.Seed(context);
        }
    }
    public class EFMonkeyContext : DbContext
    {
        public EFMonkeyContext()
        {   
            // Build connection string
            //SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            //builder.DataSource = "db702146810.db.1and1.com";   // update me
            //builder.UserID = "dbo702146810";              // update me
            //builder.Password = "1959ortsac";      // update me
            //builder.InitialCatalog = "db702146810";
            //this.Database.Connection.ConnectionString = builder.ConnectionString;

            //EFMonkeyContext db = new EFMonkeyContext();
            //db.Database.Initialize(true);

            SqlConnectionStringBuilder myBuilder = new SqlConnectionStringBuilder();            
            myBuilder.ConnectionString = "Data Source=DESKTOP-KU3S3Q9;Initial Catalog =db702146810; Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            this.Database.Connection.ConnectionString = myBuilder.ConnectionString;
        }


        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            
            //Database.SetInitializer<EFMonkeyContext>(new DropCreateDatabaseAlways<EFMonkeyContext>());

            //Database.SetInitializer<EFMonkeyContext>(null);
            Database.SetInitializer(new EFMonkeyInitializer());
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();
            modelBuilder.Configurations.Add(new UserMap());
            modelBuilder.Configurations.Add(new CorporationMap());
            modelBuilder.Configurations.Add(new AddressMap());
            modelBuilder.Configurations.Add(new LoginMap());
            modelBuilder.Configurations.Add(new UserProjectMap());
        }
        public DbSet<User> User { get; set; }
        public DbSet<UserType> UserType { get; set; }
        public DbSet<Login> Login { get; set; }
        public DbSet<Corporation> Corporation { get; set; }
        public DbSet<Address> Address { get; set; }
        public DbSet<Project> Project { get; set; }
        public DbSet<Task> Task { get; set; }
        public DbSet<TaskAdmin> TaskAdmin { get; set; }
        public DbSet<TaskPriority> TaskPriority { get; set; }
        public DbSet<TaskProgress> TaskProgress { get; set; }
        public DbSet<Document> Document { get; set; }
        public DbSet<Message> Message { get; set; }
        public DbSet<Registration> Registration { get; set; }
        public DbSet<UserProject> UserProject { get; set; }


        //public override int SaveChanges()
        //{
        //    //AddTimestamps();
        //    return base.SaveChanges();
        //}

        private void AddTimestamps()
        {
            var entities = ChangeTracker.Entries().Where(x => x.Entity is Entity && (x.State == EntityState.Added || x.State == EntityState.Modified));

            //var currentUsername = !string.IsNullOrEmpty(System.Web.HttpContext.Current?.User?.Identity?.Name)
            //    ? HttpContext.Current.User.Identity.Name
            //    : "Anonymous";

            foreach (var entity in entities)
            {
                if (entity.State == EntityState.Added)
                {
                    ((Entity)entity.Entity).UpdateDate = DateTime.UtcNow;
                    ((Entity)entity.Entity).CreateDate = DateTime.UtcNow;
                }

                ((Entity)entity.Entity).UpdateDate = DateTime.UtcNow;
                ((Entity)entity.Entity).CreateDate = DateTime.UtcNow;
            }
        }
    }
}
