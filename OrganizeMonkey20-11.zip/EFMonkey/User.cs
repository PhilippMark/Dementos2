﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            this.HasKey(u => u.Id);
            this.HasRequired(u => u.Address).WithRequiredPrincipal(a => a.User);
            this.HasRequired(u => u.Corporation).WithMany(p => p.CorporationUsers);
            this.HasMany(u => u.Sender).WithOptional(m => m.Sender);
            this.HasMany(u => u.Receiver).WithOptional(m => m.Receiver);     
            this.HasMany(u => u.Documents).WithRequired(d => d.DocumentOwner);      
            this.HasOptional(s => s.Login).WithRequired(ad => ad.User);
            this.HasMany(u => u.ProjectAdmins).WithRequired(p => p.ProjectAdmin);
            this.HasMany(a => a.Projects)
                .WithMany(p => p.Users)
                .Map(x =>
                {
                    x.MapLeftKey("User_Id");
                    x.MapRightKey("Project_Id");
                    x.ToTable("UserProject");
                });
        }
    }



    public class User : Entity
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public DateTime? Birthday { get; set; }
        public UserType UserType { get; set; }
        public bool CorporationAdmin { get; set; }

        public IList<Project> ProjectAdmins { get; set; }
        public IList<Project> Projects { get; set; }

        public Corporation Corporation { get; set; }
        public virtual IList<Document> Documents { get; set; }
        public virtual IList<Message> Sender { get; set; }
        public virtual IList<Message> Receiver { get; set; }
        public virtual IList<Task> TaskAdmins { get; set; }

        public virtual Login Login { get; set; }
        
        public virtual Address Address { get; set; }
        

        public String GetFullName()
        {
            return this.FirstName + " " + this.LastName;
        }
        public override string ToString()
        {
            return "User [id=" + this.Id + ", name=" + this.GetFullName() + "]";
        }


        public int? GetLogin(string login, string password)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {   
                return context.Login.FirstOrDefault(l => l.LoginName == login && l.Password == password).User.Id;
            }
        }

        public void InsertUserAdmin(string login)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                Login loginEntity = new Login();
                loginEntity.LoginName = login;
                loginEntity.Password = "test";



                EFMonkey.User user = new EFMonkey.User();
                user.FirstName = "Thomas";
                user.LastName = "Schmidt";
                Address adress = new Address();
                user.Address = adress;

                context.User.Add(user);
                context.Login.Add(loginEntity);
                context.Address.Add(adress);


                context.SaveChanges();
            }
        }

    }
}
