﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    class ProjectMap : EntityTypeConfiguration<Project>
    {
        public ProjectMap()
        {
            this.HasKey(u => u.Id);
            this.HasMany(p => p.Tasks).WithRequired(t => t.Project);
            this.HasRequired(u => u.ProjectAdmin).WithMany(p => p.ProjectAdmins);
            this.HasMany(a => a.Users)
                .WithMany(p => p.Projects)
                .Map(x =>
                {
                    x.MapLeftKey("Project_Id");
                    x.MapRightKey("User_Id");
                    x.ToTable("UserProject");
                });
        }
    }

    public class Project : Entity
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public IList<User> Users { get; set; }

        public virtual IList<Task> Tasks { get; set; }

        public User ProjectAdmin { get; set; }
        public Corporation Corporation { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }

}
