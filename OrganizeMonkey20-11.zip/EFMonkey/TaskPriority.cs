﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  EFMonkey
{
    public class TaskPriority : Entity
    {
        public string Name { get; set; }
        public IList<Task> Tasks { get; set; }
        public int PriorityValue { get; set; }

    }
}
