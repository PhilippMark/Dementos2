﻿using EFMonkey;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administration
{
    public class Project
    {
        public void SaveProject(String name, String text, List<int> userIds, int userId, int corporationId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                EFMonkey.Corporation corp = context.Corporation.First(c => c.Id == corporationId);
                EFMonkey.User user = context.User.First(u => u.Id == userId);
                List<EFMonkey.User> userList = new List<EFMonkey.User>();
                userList = GetUserListByIds(userIds);


                EFMonkey.Project pro = new EFMonkey.Project();
                pro.Corporation = corp;
                pro.ProjectAdmin = user;
                pro.Name = name;
                pro.Description = text;
                
                context.Project.Add(pro);
                context.SaveChanges();

                int projectID = pro.Id;
                foreach (EFMonkey.User userItem in userList)
                {
                    EFMonkey.Project project = context.Project.First(u => u.Id == projectID);
                    EFMonkey.User user2 = context.User.First(us => us.Id == userItem.Id);
                    if (user2.Projects == null)
                        user2.Projects = new List<EFMonkey.Project>();

                    if(project != null && user2 != null)
                    {
                        user2.Projects.Add(project);
                    }
                }

                context.SaveChanges();
            }
        }

        public void UpdateProject(String name, String text, int userId, List<int> userIds, int projectId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {   
                EFMonkey.Project pro = context.Project.SingleOrDefault(p => p.Id == projectId);
                List<EFMonkey.User> userList = new List<EFMonkey.User>();
                userList = GetUserListByIds(userIds);

                pro.Name = name;
                pro.Description = text;

                int projectID = pro.Id;
                List<EFMonkey.Project> projectsToDelete = context.Project.Include(e => e.Users).Where(p => p.Id == projectId).ToList(); 
                foreach(EFMonkey.Project projectToDelete in projectsToDelete)
                {
                    projectToDelete.Users = new List<EFMonkey.User>();
                }
                context.SaveChanges();

                foreach (EFMonkey.User userItem in userList)
                {
                    EFMonkey.Project project = context.Project.First(u => u.Id == projectID);
                    EFMonkey.User user2 = context.User.First(us => us.Id == userItem.Id);
                    if (user2.Projects == null)
                        user2.Projects = new List<EFMonkey.Project>();

                    if (project != null && user2 != null)
                    {
                        user2.Projects.Add(project);
                    }
                    context.SaveChanges();
                }

                context.Project.Attach(pro);
                var entry = context.Entry(pro);
                entry.Property(e => e.Name).IsModified = true;
                entry.Property(e => e.Description).IsModified = true;
                // other changed properties
                context.SaveChanges();
            }
        }

        public DataTable GetProjectsByAdmin(int userId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                IList<EFMonkey.Project> projects = context.Project.Where(p => p.ProjectAdmin.Id == userId).ToList();
                DataTable table = new DataTable();
                if (projects.Count > 0)
                {   
                    table.Columns.Add("name");
                    table.Columns.Add("text");
                    table.Columns.Add("id");

                    foreach (EFMonkey.Project project in projects)
                    {
                        DataRow row = table.NewRow();
                        row["name"] = project.Name;
                        row["text"] = project.Description;
                        row["id"] = project.Id;
                        table.Rows.Add(row);
                        table.AcceptChanges();
                    }
                }
                return table;
            }
        }

        public DataTable GetProjectsByUser(int userId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                var user = context.User.Include(cs => cs.Projects).First(u => u.Id == userId);
                IList<EFMonkey.Project> projects = user.Projects.ToList();
                DataTable table = new DataTable();
                if (projects.Count > 0)
                {
                    table.Columns.Add("name");
                    table.Columns.Add("text");
                    table.Columns.Add("id");

                    foreach (EFMonkey.Project project in projects)
                    {
                        DataRow row = table.NewRow();
                        row["name"] = project.Name;
                        row["text"] = project.Description;
                        row["id"] = project.Id;
                        table.Rows.Add(row);
                        table.AcceptChanges();
                    }
                }
                return table;
            }
        }

        public Dictionary<string, string> GetProject(int projectId)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                EFMonkey.Project project = context.Project.SingleOrDefault(p => p.Id == projectId);
                if (project != null)
                {
                    values.Add("name", project.Name);
                    values.Add("text", project.Description);
                }

            }
            return values;
        }

        protected List<EFMonkey.User> GetUserListByIds(List<int> userIds)
        {
            Administration.User user = new Administration.User();
            List<EFMonkey.User> userList = new List<EFMonkey.User>();
            foreach(int userId in userIds)
            {
                userList.Add(user.GetUserById(userId));
            }
            return userList;
        }

        public DataTable GetProjectsByCorporation(int corporationId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                IList<EFMonkey.Project> projects = context.Project.Where(p => p.Corporation.Id == corporationId).ToList();
                DataTable table = new DataTable();
                if (projects.Count > 0)
                {
                    table.Columns.Add("name");
                    table.Columns.Add("id");

                    foreach (EFMonkey.Project project in projects)
                    {
                        DataRow row = table.NewRow();
                        row["name"] = project.Name;
                        row["id"] = project.Id;
                        table.Rows.Add(row);
                        table.AcceptChanges();
                    }
                }
                return table;
            }
        }
        public DataTable GetUsersByProject(int projectId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                var user = context.Project.Include(cs => cs.Users).First(u => u.Id == projectId).Users.ToList();
                DataTable table = new DataTable();
                if (user.Count > 0)
                {
                    table.Columns.Add("name");
                    table.Columns.Add("id");

                    foreach (EFMonkey.User userEntry in user)
                    {
                        DataRow row = table.NewRow();
                        row["name"] = userEntry.FirstName + " " + userEntry.LastName;
                        row["id"] = userEntry.Id;
                        table.Rows.Add(row);
                        table.AcceptChanges();
                    }
                }
                return table;
            }
        }


        

    }
}
