﻿using EFMonkey;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administration
{
    public class Corporation
    {
        public EFMonkey.Corporation GetCorporationByUserId(int userId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                return context.User.Include(e => e.Corporation).Where(c => c.Id == userId).First().Corporation;
            }
        }

        public int GetCorporationIdByUserId(int userId)
        {
            using (EFMonkeyContext context = new EFMonkey.EFMonkeyContext())
            {
                //List<EFMonkey.Project> projectsToDelete = context.Project.Include(e => e.Users).Where(p => p.Id == projectId).ToList();
                int i = context.User.Include(e => e.Corporation).Where(c => c.Id == userId).First().Corporation.Id;
                return i;
            }
        }
    }
}
