﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OrganizeMonkey
{
    public partial class RegisterCorporation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void ButtonCreate_Click(object sender, EventArgs e)
        {
            Administration.User user = new Administration.User();
            bool isLocal = HttpContext.Current.Request.IsLocal;
            if ((!isLocal && textNameCreate.Text.StartsWith("ihk_")) || isLocal)
            {
                user.InsertUserAdmin(textLoginCreate.Text, textPasswordCreate.Text, textNameCreate.Text, txtFirstname.Text, txtLastname.Text);
            }
        }
    }
}