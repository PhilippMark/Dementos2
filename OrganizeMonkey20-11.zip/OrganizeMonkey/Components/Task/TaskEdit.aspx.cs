﻿using Administration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OrganizeMonkey.Components.Task
{
    public partial class TaskEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["projectid"] != null)
            {
                if (!Page.IsPostBack)
                    FillMask();
                btnSave.Text = "Aktualisieren";

            }
        }

        protected DataTable GetUsersByCorporation()
        {
            Administration.User user = new Administration.User();

            int corpId = Convert.ToInt32(Session["corporation"].ToString());

            return user.GetUsersByCorporation(corpId);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            User user = new User();
            Administration.Project project = new Administration.Project();

            int userId = Convert.ToInt32(Session["user"].ToString());
            if (Request.QueryString["projectid"] != null)
            {
                int projectId = Convert.ToInt32(Request.QueryString["projectid"].ToString());
                //project.SaveProject(txtName.Text, RichTextBox.Text, userId, projectId);
            }
            else
            {
                //project.SaveProject(txtName.Text, RichTextBox.Text, userId);
            }

        }

        protected void FillMask()
        {
            Administration.Project project = new Administration.Project();

            int projectId = Convert.ToInt32(Request.QueryString["projectid"].ToString());
            Dictionary<string, string> dict = project.GetProject(projectId);

            txtName.Text = dict["name"];
            RichTextBox.Text = dict["text"];
        }

        
        protected void dropdownUsers_Init(object sender, EventArgs e)
        {
            if (DropDownListProjects.SelectedItem != null)
            {
                Administration.Project project = new Administration.Project();
                DataTable users = new DataTable();
                users = project.GetUsersByProject(Convert.ToInt32(DropDownListProjects.SelectedValue));
                dropdownUsers.DataSource = users;
                dropdownUsers.DataTextField = "name";
                dropdownUsers.DataValueField = "id";
                dropdownUsers.DataBind();
            }
            else
            {
                DropDownListProjects.Visible = false;
            }
        }

        protected void DropDownListProjects_Init(object sender, EventArgs e)
        {
            Administration.Project project = new Administration.Project();
            int corpId = Convert.ToInt32(Session["corporation"].ToString());

            DataTable projects = new DataTable();
            projects = project.GetProjectsByCorporation(corpId);
            DropDownListProjects.DataSource = projects;
            DropDownListProjects.DataTextField = "name";
            DropDownListProjects.DataValueField = "id";
            DropDownListProjects.DataBind();

            
        }
    }
}
