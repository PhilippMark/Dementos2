﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OrganizeMonkey.Components.Project
{
    public partial class ProjectList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            reapeater.DataSource = GetProjectsByUser();
            reapeater.DataBind();
        }

        protected DataTable GetProjectsByUser()
        {
            Administration.Project project = new Administration.Project();

            int userId = Convert.ToInt32(Session["user"].ToString());
            
            return project.GetProjectsByUser(userId);

        }
    }
}