﻿using Administration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OrganizeMonkey.Components.Project
{
    public partial class ProjectEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Request.QueryString["projectid"] != null)
            {
                if (!Page.IsPostBack)
                {
                    FillMask();
                    btnSave.Text = "Aktualisieren";
                    repeaterUser.DataSource = GetUsersByCorporation();
                    repeaterUser.DataBind();
                }
            }
            if (!Page.IsPostBack)
            {                
                repeaterUser.DataSource = GetUsersByCorporation();
                repeaterUser.DataBind();
            }


        }

        protected DataTable GetUsersByCorporation()
        {
            Administration.User user = new Administration.User();

            int corpId = Convert.ToInt32(Session["corporation"].ToString());

            return user.GetUsersByCorporation(corpId);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            User user = new User();
            Administration.Project project = new Administration.Project();

            List<int> userIds = new List<int>();
            foreach(RepeaterItem userCheckbox in repeaterUser.Items)
            {
                System.Web.UI.HtmlControls.HtmlInputCheckBox checkBox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)userCheckbox.FindControl("chk");
                if(checkBox != null && checkBox.Checked)
                {
                    userIds.Add(Convert.ToInt32(checkBox.Value));
                }
            }

            int userId = Convert.ToInt32(Session["user"].ToString());
            if (Request.QueryString["projectid"] != null)
            {
                int projectId = Convert.ToInt32(Request.QueryString["projectid"].ToString());
                project.UpdateProject(txtName.Text, txtRichTextBox.Text, userId, userIds, projectId);
            }
            else
            {
                int corpId = Convert.ToInt32(Session["corporation"].ToString());
                project.SaveProject(txtName.Text, txtRichTextBox.Text, userIds, userId,corpId);
            }
                
        }

        protected void FillMask()
        {
            Administration.Project project = new Administration.Project();

            int projectId = Convert.ToInt32(Request.QueryString["projectid"].ToString());
            Dictionary<string, string> dict = project.GetProject(projectId);

            txtName.Text = dict["name"];
            txtRichTextBox.Text = dict["text"];
        }
    }
}