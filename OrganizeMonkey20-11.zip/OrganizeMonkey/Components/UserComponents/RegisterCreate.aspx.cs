﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OrganizeMonkey.Components.UserComponents
{
    public partial class RegisterCreate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        public string Encrypt(string encryptString)
        {
            string EncryptionKey = "registermonkey";
            byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
                    0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
                });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    encryptString = Convert.ToBase64String(ms.ToArray());
                }
            }
            return encryptString;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {

            string date = HttpUtility.UrlEncode(Encrypt(DateTime.Now.ToUniversalTime().ToString().Trim().Replace(' ', 'A')));
            string corporation = HttpUtility.UrlEncode(Encrypt(Session["corporation"].ToString()));


            string url = Request.Url.GetLeftPart(UriPartial.Authority) + "/Registration.aspx?";
            string parameters = string.Format("date={0}&corporation={1}", date, corporation);

            lblCreate.Text = url + parameters;
            lblLink.Visible = true;
            btnCreate.Enabled = false;
        }
    }
}